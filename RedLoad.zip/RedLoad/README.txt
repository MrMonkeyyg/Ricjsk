خطوات بناء الـ APK (مجاناً):
1) أنشئ حساباً على github.com ثم مستودعاً جديداً (New repository) باسم RedLoad.
2) ارفع محتويات هذا المجلد كلها (بما فيها المجلد المخفي .github) عبر "Add file > Upload files".
   إن لم يظهر المجلد المخفي في جهازك فأنشئ الملف يدوياً: .github/workflows/build.yml وانسخ محتواه.
3) افتح تبويب Actions وانتظر 5-10 دقائق حتى يكتمل "Build APK" (علامة خضراء).
4) افتح آخر عملية بناء، وحمّل RedLoad-apk من قسم Artifacts، فك الضغط ثم ثبّت ملف app-debug.apk.
التنزيلات تُحفظ في: Download/RedLoad
