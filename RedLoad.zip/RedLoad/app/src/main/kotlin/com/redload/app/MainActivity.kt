package com.redload.app
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.yausername.youtubedl_android.YoutubeDL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var urlBox: EditText
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var shareBtn: Button
    private val red = Color.parseColor("#E53935")
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, filled: Boolean) = Button(this).apply {
        text = t; isAllCaps = false
        setTextColor(if (filled) Color.WHITE else red)
        setBackgroundColor(if (filled) red else Color.parseColor("#FDECEA"))
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = red
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = TextView(this).apply {
            text = "RedLoad"; textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(red)
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        urlBox = EditText(this).apply { hint = "ألصق رابط الفيديو هنا"; setSingleLine(true) }
        val row = LinearLayout(this)
        val paste = btn("لصق", false)
        val go = btn("تحليل وتنزيل", true)
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(dp(4), dp(8), dp(4), 0) }
        row.addView(paste, lp); row.addView(go, lp)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        status = TextView(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(16), 0, dp(8)) }
        shareBtn = btn("مشاركة الملف", true).apply { visibility = View.GONE }
        body.addView(urlBox); body.addView(row); body.addView(bar); body.addView(status); body.addView(shareBtn)
        root.addView(top); root.addView(body)
        setContentView(root)

        paste.setOnClickListener {
            val cm = getSystemService(ClipboardManager::class.java)
            urlBox.setText(cm.primaryClip?.getItemAt(0)?.text ?: "")
        }
        go.setOnClickListener { analyze(urlBox.text.toString().trim()) }
        shareBtn.setOnClickListener {
            val u = Bus.uri ?: return@setOnClickListener
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = Bus.mime; putExtra(Intent.EXTRA_STREAM, u); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "مشاركة"))
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        thread { try { Engine.init(this); YoutubeDL.getInstance().updateYoutubeDL(this) } catch (_: Exception) {} }
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }

    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val m = Regex("https?://\\S+").find(i.getStringExtra(Intent.EXTRA_TEXT) ?: "")
            if (m != null) { urlBox.setText(m.value); analyze(m.value) }
        }
    }

    override fun onStart() { super.onStart(); Bus.listener = { render() }; render() }
    override fun onStop() { super.onStop(); Bus.listener = null }

    private fun render() {
        if (Bus.msg.isEmpty()) return
        status.text = Bus.msg
        bar.visibility = View.VISIBLE; bar.progress = Bus.pct
        shareBtn.visibility = if (Bus.uri != null) View.VISIBLE else View.GONE
    }

    private fun analyze(url: String) {
        if (!url.startsWith("http")) { status.text = "الرابط غير صحيح"; return }
        status.text = "جارٍ تحليل الرابط..."; bar.visibility = View.GONE; shareBtn.visibility = View.GONE
        thread {
            try {
                Engine.init(this)
                val info = YoutubeDL.getInstance().getInfo(url)
                val fs = info.formats ?: emptyList()
                fun size(v: Long) = if (v > 0) "%.1f MB".format(v / 1048576.0) else "؟"
                val audioSz = fs.filter { (it.vcodec ?: "none") == "none" }
                    .maxOfOrNull { (it.fileSize ?: 0L).takeIf { s -> s > 0 } ?: (it.fileSizeApproximate ?: 0L) } ?: 0L
                val heights = fs.filter { (it.vcodec ?: "none") != "none" }.map { it.height ?: 0 }.filter { it >= 144 }.distinct().sortedDescending()
                val labels = ArrayList<String>(); val hs = ArrayList<Int>()
                for (h in heights) {
                    val v = fs.filter { (it.height ?: 0) == h && (it.vcodec ?: "none") != "none" }
                        .maxOfOrNull { (it.fileSize ?: 0L).takeIf { s -> s > 0 } ?: (it.fileSizeApproximate ?: 0L) } ?: 0L
                    labels.add("MP4 فيديو ${h}p  •  ${size(if (v > 0) v + audioSz else 0)}"); hs.add(h)
                }
                if (hs.isEmpty()) { labels.add("MP4 فيديو (أفضل جودة)"); hs.add(4320) }
                labels.add("MP3 صوت فقط  •  ${size(audioSz)}"); hs.add(-1)
                runOnUiThread {
                    status.text = info.title ?: ""
                    AlertDialog.Builder(this).setTitle("اختر الصيغة والجودة")
                        .setItems(labels.toTypedArray()) { _, i ->
                            Bus.reset()
                            Bus.post(0, "بدء التنزيل...")
                            startForegroundService(Intent(this, DownloadService::class.java)
                                .putExtra("url", url).putExtra("id", info.id ?: "x")
                                .putExtra("h", hs[i]).putExtra("audio", hs[i] == -1))
                        }.show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "تعذّر تحليل الرابط: ${e.message?.take(100)}" }
            }
        }
    }
}
