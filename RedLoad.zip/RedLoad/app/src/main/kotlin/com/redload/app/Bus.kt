package com.redload.app
import android.net.Uri
import android.os.Handler
import android.os.Looper

object Bus {
    var pct = 0; var msg = ""; var uri: Uri? = null; var mime = ""
    var listener: (() -> Unit)? = null
    fun reset() { pct = 0; msg = ""; uri = null }
    fun post(p: Int, m: String, u: Uri? = null, mi: String = "") {
        pct = p; msg = m
        if (u != null) { uri = u; mime = mi }
        Handler(Looper.getMainLooper()).post { listener?.invoke() }
    }
}
