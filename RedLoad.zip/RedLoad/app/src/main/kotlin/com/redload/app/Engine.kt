package com.redload.app
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL

object Engine {
    private var ready = false
    @Synchronized fun init(c: Context) {
        if (ready) return
        YoutubeDL.getInstance().init(c.applicationContext)
        FFmpeg.getInstance().init(c.applicationContext)
        ready = true
    }
}
