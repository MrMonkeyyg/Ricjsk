package com.redload.app
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.os.IBinder
import android.provider.MediaStore
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import kotlin.concurrent.thread

class DownloadService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("dl", "التنزيلات", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif("جارٍ التحضير...", 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        val url = i.getStringExtra("url")!!
        val vid = i.getStringExtra("id") ?: "x"
        val h = i.getIntExtra("h", 0)
        val audio = i.getBooleanExtra("audio", false)
        thread {
            try { run(url, vid, h, audio) } catch (e: Exception) { Bus.post(0, "فشل: ${e.message?.take(120)}") }
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }
        return START_REDELIVER_INTENT
    }

    private fun notif(t: String, p: Int): Notification =
        Notification.Builder(this, "dl").setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("RedLoad").setContentText(t).setOngoing(true).setProgress(100, p, p == 0).build()

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        return cm.getNetworkCapabilities(cm.activeNetwork) != null
    }

    private fun run(url: String, vid: String, h: Int, audio: Boolean) {
        Engine.init(this)
        val dir = File(getExternalFilesDir(null), "tmp").apply { mkdirs() }
        val nm = getSystemService(NotificationManager::class.java)
        var done = false; var attempt = 0
        while (!done && attempt < 200) {
            try {
                val r = YoutubeDLRequest(url)
                r.addOption("-o", dir.absolutePath + "/%(title).80s [%(id)s].%(ext)s")
                r.addOption("-c"); r.addOption("--no-playlist"); r.addOption("--no-mtime")
                r.addOption("--retries", "infinite"); r.addOption("--fragment-retries", "infinite")
                r.addOption("--socket-timeout", "20")
                if (audio) {
                    r.addOption("-f", "bestaudio/best"); r.addOption("-x")
                    r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "0")
                } else {
                    r.addOption("-f", "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]/b")
                    r.addOption("--merge-output-format", "mp4")
                }
                YoutubeDL.getInstance().execute(r, "dl$vid") { p, _, _ ->
                    val pc = p.toInt().coerceIn(0, 100)
                    Bus.post(pc, "جارٍ التنزيل... $pc%")
                    nm.notify(1, notif("$pc%", pc))
                }
                done = true
            } catch (e: Exception) {
                attempt++
                Bus.post(Bus.pct, "انقطع الاتصال، سيُستأنف التنزيل تلقائياً...")
                while (!online()) Thread.sleep(2000)
                Thread.sleep(3000)
            }
        }
        if (!done) { Bus.post(0, "تعذّر إكمال التنزيل، أعد المحاولة"); return }
        val ok = setOf("mp4", "mp3", "mkv", "webm", "m4a")
        val file = dir.listFiles()?.filter {
            it.name.contains("[$vid]") && it.extension in ok && !Regex("\\.f\\d+\\.").containsMatchIn(it.name)
        }?.maxByOrNull { it.lastModified() }
        if (file == null) { Bus.post(0, "لم يُعثر على الملف"); return }
        val mime = when (file.extension) { "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"; else -> "video/mp4" }
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, file.name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/RedLoad")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        file.delete()
        Bus.post(100, "تم التنزيل ✔ (مجلد Download/RedLoad)", uri, mime)
    }
}
